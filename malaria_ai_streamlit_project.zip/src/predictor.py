
import tensorflow as tf
from src.preprocess import preprocess

MODEL_PATH = "model/malaria_cnn.h5"

model = tf.keras.models.load_model(MODEL_PATH)

def predict(image):
    processed = preprocess(image)
    pred = model.predict(processed)[0][0]

    if pred > 0.5:
        return "Parasitized", float(pred)
    else:
        return "Uninfected", float(1-pred)
